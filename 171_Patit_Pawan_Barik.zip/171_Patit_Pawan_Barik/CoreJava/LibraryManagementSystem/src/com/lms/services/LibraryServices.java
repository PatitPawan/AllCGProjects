package com.lms.services;
import java.util.List;
import com.lms.beans.Address;
import com.lms.beans.Book;
import com.lms.beans.Date;
import com.lms.beans.Member;
import com.lms.beans.Person;

public interface LibraryServices {
	Book acceptBookDetails(String bookName, String publisher, String author, float price);
	Member acceptMemberDetails(Person person);
	Book issueBook(long memberId, long bookId, Date issueDate, Date submitDate);
	Book returnBook(long memberId, long bookId, Date issueDate, Date submitDate);
	double calculateLateFee(long memberId, long bookId);
	List<Book>getMemberAllBooksDetails(long memberId);
	List<Member>allMemberDetails();
}
