package com.lms.services;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.lms.beans.Address;
import com.lms.beans.Book;
import com.lms.beans.BookIssueRecord;
import com.lms.beans.Date;
import com.lms.beans.Member;
import com.lms.beans.Person;
import com.lms.daoservices.BookDAO;
import com.lms.daoservices.BookDAOImpl;
import com.lms.daoservices.MemberDAO;
import com.lms.daoservices.MemberDAOImpl;
import com.lms.exceptions.BookDetailsNotFoundException;
import com.lms.exceptions.LibraryCardBlockedException;
import com.lms.exceptions.LibraryServicesDownException;
import com.lms.exceptions.MemberDetailsNotFoundException;
import com.lms.util.LibraryDBUtil;

public class LibraryServicesImpl implements LibraryServices{
	private MemberDAO memberDao = new MemberDAOImpl();
	private BookDAO bookDao = new BookDAOImpl();
	@Override
	public Book acceptBookDetails(String bookName, String publisher, String author, float price) throws LibraryServicesDownException{
		long bookId = LibraryDBUtil.getBOOK_ID_COUNTER();
		Book book = new Book(bookId, bookName, publisher, author, price);
		book = bookDao.save(book);
		return book;
	}
	@Override
	public Member acceptMemberDetails(Person person) throws LibraryServicesDownException{
		long memberId = LibraryDBUtil.getMEMBER_ID_COUNTER();
		Map<Long,Book> books = new HashMap<Long, Book>();
		Member member = new Member(memberId, person, books);
		member = memberDao.save(member);
		return member;
	}
	@Override
	public Book issueBook(long memberId, long bookId, Date issueDate, Date submitDate) throws LibraryServicesDownException, BookDetailsNotFoundException, MemberDetailsNotFoundException, LibraryCardBlockedException{
		Book book = bookDao.findOne(bookId);
		if(book==null)
			throw new BookDetailsNotFoundException("Book  "+bookId +" not found.");
		return book;
	}
	@Override
	public Book returnBook(long memberId, long bookId, Date issueDate, Date submitDate) throws LibraryServicesDownException, BookDetailsNotFoundException, MemberDetailsNotFoundException, LibraryCardBlockedException{
		Book book = bookDao.findOne(bookId);
		if(book==null)
			throw new BookDetailsNotFoundException("Book  "+bookId +" not found.");
		return book;
	}
	@Override
	public double calculateLateFee(long memberId, long bookId) throws LibraryServicesDownException, BookDetailsNotFoundException, MemberDetailsNotFoundException, LibraryCardBlockedException{
		Member member = memberDao.findOne(memberId);
		Book book = member.getBooks().get(bookId);
		BookIssueRecord bookIssue;
		return 0;
	}
	@Override
	public List<Book> getMemberAllBooksDetails(long memberId) throws LibraryServicesDownException, BookDetailsNotFoundException, MemberDetailsNotFoundException, LibraryCardBlockedException{
		Member member = memberDao.findOne(memberId);
		ArrayList<Book> bookList =(ArrayList<Book>) member.getBooks().values();
		return bookList;
	}
	@Override
	public List<Member> allMemberDetails() throws LibraryServicesDownException, BookDetailsNotFoundException, MemberDetailsNotFoundException, LibraryCardBlockedException{

		return memberDao.findAll();
	}

	
}
