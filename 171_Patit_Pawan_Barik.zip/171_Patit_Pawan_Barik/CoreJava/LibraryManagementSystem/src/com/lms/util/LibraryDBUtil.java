package com.lms.util;

import java.util.HashMap;

import com.lms.beans.Book;
import com.lms.beans.Member;

public class LibraryDBUtil {
	public static HashMap<Long, Member> members = new HashMap<>();
	public static HashMap<Long, Book> books = new HashMap<>();
	static long BOOK_ID_COUNTER=100;
	static long MEMBER_ID_COUNTER=10000;
	public static long getBOOK_ID_COUNTER() {
		return ++BOOK_ID_COUNTER;
	}
	public static long getMEMBER_ID_COUNTER() {
		return ++MEMBER_ID_COUNTER;
	}
}
