package com.lms.beans;

import java.util.Map;

public class Member {
	long memberId = 0;
	Person person;
	Map<Long,Book> books;
	public Member() {
		super();
	}
	public Member(long memberId, Person person, Map<Long, Book> books) {
		super();
		this.memberId = memberId;
		this.person = person;
		this.books = books;
	}
	public long getMemberId() {
		return memberId;
	}
	public void setMemberId(long memberId) {
		this.memberId = memberId;
	}
	public Person getPerson() {
		return person;
	}
	public void setPerson(Person person) {
		this.person = person;
	}
	public Map<Long, Book> getBooks() {
		return books;
	}
	public void setBooks(Map<Long, Book> books) {
		this.books = books;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((books == null) ? 0 : books.hashCode());
		result = prime * result + (int) (memberId ^ (memberId >>> 32));
		result = prime * result + ((person == null) ? 0 : person.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Member other = (Member) obj;
		if (books == null) {
			if (other.books != null)
				return false;
		} else if (!books.equals(other.books))
			return false;
		if (memberId != other.memberId)
			return false;
		if (person == null) {
			if (other.person != null)
				return false;
		} else if (!person.equals(other.person))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Member [memberId=" + memberId + ", person=" + person + ", books=" + books + "]";
	}
}
