package com.lms.beans;

public class BookIssueRecord {
	Date bookIssueDate = null;
	Date bookSubmitDate = null;
	boolean bookAvailable = true;
	Book book;
	public BookIssueRecord() {
		super();
	}
	public BookIssueRecord(Date bookIssueDate, Date bookSubmitDate, boolean bookAvailable, Book book) {
		super();
		this.bookIssueDate = bookIssueDate;
		this.bookSubmitDate = bookSubmitDate;
		this.bookAvailable = bookAvailable;
		this.book = book;
	}
	public Date getBookIssueDate() {
		return bookIssueDate;
	}
	public void setBookIssueDate(Date bookIssueDate) {
		this.bookIssueDate = bookIssueDate;
	}
	public Date getBookSubmitDate() {
		return bookSubmitDate;
	}
	public void setBookSubmitDate(Date bookSubmitDate) {
		this.bookSubmitDate = bookSubmitDate;
	}
	public boolean isBookAvailable() {
		return bookAvailable;
	}
	public void setBookAvailable(boolean bookAvailable) {
		this.bookAvailable = bookAvailable;
	}
	public Book getBook() {
		return book;
	}
	public void setBook(Book book) {
		this.book = book;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((book == null) ? 0 : book.hashCode());
		result = prime * result + (bookAvailable ? 1231 : 1237);
		result = prime * result + ((bookIssueDate == null) ? 0 : bookIssueDate.hashCode());
		result = prime * result + ((bookSubmitDate == null) ? 0 : bookSubmitDate.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BookIssueRecord other = (BookIssueRecord) obj;
		if (book == null) {
			if (other.book != null)
				return false;
		} else if (!book.equals(other.book))
			return false;
		if (bookAvailable != other.bookAvailable)
			return false;
		if (bookIssueDate == null) {
			if (other.bookIssueDate != null)
				return false;
		} else if (!bookIssueDate.equals(other.bookIssueDate))
			return false;
		if (bookSubmitDate == null) {
			if (other.bookSubmitDate != null)
				return false;
		} else if (!bookSubmitDate.equals(other.bookSubmitDate))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "BookIssueRecord [bookIssueDate=" + bookIssueDate + ", bookSubmitDate=" + bookSubmitDate
				+ ", bookAvailable=" + bookAvailable + ", book=" + book + "]";
	}
}
