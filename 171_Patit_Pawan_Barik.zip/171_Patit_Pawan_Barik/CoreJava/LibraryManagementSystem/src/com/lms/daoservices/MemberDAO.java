package com.lms.daoservices;

import java.util.List;
import com.lms.beans.Member;

public interface MemberDAO {
	Member save(Member member);
	boolean update(Member member);
	Member findOne(long memberId);
	List<Member> findAll();
}
