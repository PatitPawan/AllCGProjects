package com.lms.daoservices;

import java.util.ArrayList;
import java.util.List;
import com.lms.beans.Member;
import com.lms.util.LibraryDBUtil;

public class MemberDAOImpl implements MemberDAO{
	@Override
	public Member save(Member member) {
		member.setMemberId(LibraryDBUtil.getMEMBER_ID_COUNTER());
		LibraryDBUtil.members.put(member.getMemberId(), member);
		return member;
	}
	@Override
	public boolean update(Member member) {
		return false;
	}
	@Override
	public Member findOne(long memberId) {
		return LibraryDBUtil.members.get(memberId);
	}
	@Override
	public List<Member> findAll() {
		ArrayList<Member> memberList = new ArrayList<Member>(LibraryDBUtil.members.values());
		return memberList;
	}
}
