package com.lms.daoservices;

import java.util.List;
import com.lms.beans.Book;

public interface BookDAO {
	Book save(Book book);
	boolean update(Book book);
	Book findOne(long bookId);
	List<Book> findAll();
}
