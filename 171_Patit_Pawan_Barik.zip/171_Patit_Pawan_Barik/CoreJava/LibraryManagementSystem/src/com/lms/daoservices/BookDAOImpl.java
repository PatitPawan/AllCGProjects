package com.lms.daoservices;

import java.util.ArrayList;
import java.util.List;
import com.lms.beans.Book;
import com.lms.beans.Member;
import com.lms.util.LibraryDBUtil;

public class BookDAOImpl implements BookDAO{

	@Override
	public Book save(Book book) {
		book.setBookId(LibraryDBUtil.getMEMBER_ID_COUNTER());
		LibraryDBUtil.books.put(book.getBookId(), book);
		return book;
	}
	@Override
	public boolean update(Book book) {
		return false;
	}
	@Override
	public Book findOne(long bookId) {
		return LibraryDBUtil.books.get(bookId);
	}
	@Override
	public List<Book> findAll() {
		ArrayList<Book> bookList = new ArrayList<Book>(LibraryDBUtil.books.values());
		return bookList;
	}
}
