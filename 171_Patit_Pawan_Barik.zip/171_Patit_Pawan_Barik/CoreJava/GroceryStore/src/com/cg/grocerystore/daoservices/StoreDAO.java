package com.cg.grocerystore.daoservices;

import java.util.List;
import com.cg.grocerystore.beans.Product;

public interface StoreDAO {
	Product save(Product product);
	boolean update(Product product);
	Product findOne(long productId);
	List<Product> findAll();
}
