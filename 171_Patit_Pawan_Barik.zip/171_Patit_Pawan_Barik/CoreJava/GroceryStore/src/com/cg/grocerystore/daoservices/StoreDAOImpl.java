package com.cg.grocerystore.daoservices;

import java.util.List;

import com.cg.grocerystore.beans.Product;
import com.cg.grocerystore.util.GroceryStoreDBUtil;

public class StoreDAOImpl implements StoreDAO{

	@Override
	public Product save(Product product) {
		product.setProductId(GroceryStoreDBUtil.getPRODUCT_ID_COUNTER());
		return product;
	}
	@Override
	public boolean update(Product product) {
		return false;
	}
	@Override
	public Product findOne(long productId) {
		return null;
	}
	@Override
	public List<Product> findAll() {
		return null;
	}
}
