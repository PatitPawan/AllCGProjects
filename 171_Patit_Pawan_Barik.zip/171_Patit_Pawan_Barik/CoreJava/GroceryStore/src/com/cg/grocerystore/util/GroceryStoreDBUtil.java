package com.cg.grocerystore.util;

import java.util.HashMap;
import com.cg.grocerystore.beans.Customer;

public class GroceryStoreDBUtil {
	public static HashMap<Long,Customer> customers = new HashMap<>();
	public static long CUSTOMER_ID_COUNTER = 100000;
	public static long PRODUCT_ID_COUNTER = 100;
	public static long getCUSTOMER_ID_COUNTER()
	{
		return ++CUSTOMER_ID_COUNTER;
	};
	public static long getPRODUCT_ID_COUNTER()
	{
		return ++PRODUCT_ID_COUNTER;
	};
}
