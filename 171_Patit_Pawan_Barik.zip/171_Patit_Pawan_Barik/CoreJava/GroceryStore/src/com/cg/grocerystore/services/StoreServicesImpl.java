package com.cg.grocerystore.services;
import java.util.ArrayList;
import java.util.List;
import com.cg.grocerystore.beans.Customer;
import com.cg.grocerystore.beans.Product;
import com.cg.grocerystore.daoservices.CustomerDAO;
import com.cg.grocerystore.daoservices.CustomerDAOImpl;
import com.cg.grocerystore.exceptions.CustomerDetailsNotFoundException;
import com.cg.grocerystore.exceptions.GroceryStoreServicesDownException;

public class StoreServicesImpl  implements StoreServices{
	private CustomerDAO customerDao = new CustomerDAOImpl();
	@Override
	public Product addProduct(Product product) throws GroceryStoreServicesDownException {
		return null;
	}
	@Override
	public Customer addCustomer(Customer customer) throws GroceryStoreServicesDownException {
		return null;
	}
	@Override
	public List<Customer> getAllCustomerDetails() throws GroceryStoreServicesDownException {
		return customerDao.findAll();
	}
	@Override
	public List<Product> getCustomerAllProducts(int CustomerId) throws GroceryStoreServicesDownException, CustomerDetailsNotFoundException {
		Customer customer = customerDao.findOne(CustomerId);
		ArrayList<Product> productList =(ArrayList<Product>) customer.getProduct().values();
		return productList;
	}
	
}
