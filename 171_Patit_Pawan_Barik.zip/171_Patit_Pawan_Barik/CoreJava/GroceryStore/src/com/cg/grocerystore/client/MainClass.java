package com.cg.grocerystore.client;

public class MainClass {
	
}
