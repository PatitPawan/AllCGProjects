package com.cg.grocerystore.daoservices;

import java.util.ArrayList;
import java.util.List;
import com.cg.grocerystore.beans.Customer;
import com.cg.grocerystore.util.GroceryStoreDBUtil;

public class CustomerDAOImpl implements CustomerDAO{

	@Override
	public Customer save(Customer customer) {
		customer.setCustomerId(GroceryStoreDBUtil.getCUSTOMER_ID_COUNTER());
		GroceryStoreDBUtil.customers.put(customer.getCustomerId(), customer);
		return customer;
	}
	@Override
	public boolean update(Customer customer) {
		return false;
	}
	@Override
	public Customer findOne(long customerId) {
		return GroceryStoreDBUtil.customers.get(customerId);
	}
	@Override
	public List<Customer> findAll() {
		ArrayList<Customer> customerList = new ArrayList<Customer>(GroceryStoreDBUtil.customers.values());
		return customerList;
	}
}
