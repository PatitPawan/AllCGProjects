package com.cg.grocerystore.services;
import java.util.List;
import com.cg.grocerystore.beans.Customer;
import com.cg.grocerystore.beans.Product;
import com.cg.grocerystore.exceptions.CustomerDetailsNotFoundException;
import com.cg.grocerystore.exceptions.GroceryStoreServicesDownException;

public interface StoreServices {
	Product addProduct(Product product) throws GroceryStoreServicesDownException;
	Customer addCustomer(Customer customer) throws GroceryStoreServicesDownException;
	List<Product> getCustomerAllProducts(int CustomerId) throws GroceryStoreServicesDownException, CustomerDetailsNotFoundException;
	List<Customer> getAllCustomerDetails() throws GroceryStoreServicesDownException;
}
