package com.cg.grocerystore.daoservices;

import java.util.List;
import com.cg.grocerystore.beans.Customer;

public interface CustomerDAO {
	Customer save(Customer customer);
	boolean update(Customer customer);
	Customer findOne(long customerId);
	List<Customer> findAll();
}
