package com.cg.mra.ui;

import java.util.Scanner;
import com.cg.mra.services.AccountService;
import com.cg.mra.services.AccountServiceImpl;

public class MainUI {
	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
        AccountService services=new AccountServiceImpl();
        boolean flag=true;
        String mobileNo;
        double rechargeAmount, newBalance;
        int choice;
        while(flag)
        {
        	System.out.println("*****************************************Welcome To Mobile Recharge Application*******************************************");
        	System.out.println("***************************************************************************************************************************");
        	System.out.println("Services:");
        	System.out.println("1. Account Balance Enquiry \t 2.Recharge Account \t 3.Exit Application");
        	System.out.println("Enter Choice: ");
        	choice = sc.nextInt();
        	switch (choice) {
			case 1: //Account Balance Enquiry
				System.out.println("Enter Your Mobile No :");  //Taking User Mobile Number Input
				mobileNo = sc.next();
				try {
					System.out.println(services.getAccountDetails(mobileNo));
				}
				catch (Exception e) {
					e.printStackTrace();
				}
				break;
			case 2: //Recharge Account 
				System.out.println("Enter Your Mobile No :");	//Taking User Mobile Number Input
				mobileNo = sc.next();
				System.out.println("Enter Recharge Amount :");//Taking Recharge Amount Input
				rechargeAmount = sc.nextDouble();
				try {
					newBalance = services.rechargeAccount(mobileNo, rechargeAmount);
					System.out.println("Your Account Recharged Successfully");
					System.out.println("Current Balance : "+ newBalance);
				}
				catch (Exception e) {
					e.printStackTrace();
				}
				break;
			case 3: //Exit Application
				flag = false;
				System.out.println("Exiting Application");
				break;
			default: 
				System.out.println("You Entered an Invalid Option. Please Try Again.");
				break;
			}
        }
	}
}
