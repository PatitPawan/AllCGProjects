package com.cg.mra.exceptions;

public class InvalidMobileNoLengthException extends RuntimeException{
	public InvalidMobileNoLengthException() {
		super();
	}
	public InvalidMobileNoLengthException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}
	public InvalidMobileNoLengthException(String message, Throwable cause) {
		super(message, cause);
	}
	public InvalidMobileNoLengthException(String message) {
		super(message);
	}
	public InvalidMobileNoLengthException(Throwable cause) {
		super(cause);
	}
}
