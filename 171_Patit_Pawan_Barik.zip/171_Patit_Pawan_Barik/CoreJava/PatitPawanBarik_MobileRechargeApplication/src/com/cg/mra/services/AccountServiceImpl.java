package com.cg.mra.services;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exceptions.AccountDetailsNotFoundException;
import com.cg.mra.exceptions.ApplicationServicesDownException;
import com.cg.mra.exceptions.InvalidAmountException;
import com.cg.mra.exceptions.InvalidMobileNoLengthException;

public class AccountServiceImpl implements AccountService{
	AccountDao accountDao = new AccountDaoImpl();
	//Get Account Details For The Given MobileNo
	@Override
	public Account getAccountDetails(String mobileNo) throws AccountDetailsNotFoundException, ApplicationServicesDownException{
		Account account = null;
		if(validateMobileNo(mobileNo)) {
			account = accountDao.getAccountDetails(mobileNo);
			if(account==null) {
				throw new AccountDetailsNotFoundException("ERROR : Account Not Found");
			}
		}
		else {
			throw new InvalidMobileNoLengthException("ERROR: MobileNo Length Not Valid.");
		}
		return account;
	}
	//Recharge Account For The Given MobileNo and Update The Account Balance With Recharge Amount
	@Override
	public double rechargeAccount(String mobileNo, double rechargeAmount) throws AccountDetailsNotFoundException, InvalidAmountException, ApplicationServicesDownException{
		Account account = getAccountDetails(mobileNo);
		double newBalance;
		if(account==null) {
			throw new AccountDetailsNotFoundException("ERROR : Cannot Recharge As Given Account Not Found");
		}
		else {
			if(rechargeAmount<=0) {
				throw new InvalidAmountException("ERROR: You Entered An Invalid Amount");
			}
			else {
				newBalance = accountDao.rechargeAccount(mobileNo, rechargeAmount); //Updating NewBalance in the DAO
			}
		}
		return newBalance;
	}
	//Validating 10-Digit MobileNo
	@Override
	public boolean validateMobileNo(String mobileNo) throws ApplicationServicesDownException{
		if(mobileNo.length()==10) {
			return true;
		}
		else {
			return false;
		}
	}
}
