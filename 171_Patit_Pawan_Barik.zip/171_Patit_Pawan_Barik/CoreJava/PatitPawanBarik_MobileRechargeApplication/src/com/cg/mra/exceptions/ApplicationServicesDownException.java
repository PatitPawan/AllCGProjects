package com.cg.mra.exceptions;

public class ApplicationServicesDownException extends RuntimeException{
	public ApplicationServicesDownException() {
		super();
	}
	public ApplicationServicesDownException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}
	public ApplicationServicesDownException(String message, Throwable cause) {
		super(message, cause);
	}
	public ApplicationServicesDownException(String message) {
		super(message);
	}
	public ApplicationServicesDownException(Throwable cause) {
		super(cause);
	}
}
