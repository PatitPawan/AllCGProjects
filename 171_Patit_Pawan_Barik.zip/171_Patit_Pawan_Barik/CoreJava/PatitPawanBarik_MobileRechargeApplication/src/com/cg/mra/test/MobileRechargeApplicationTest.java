package com.cg.mra.test;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exceptions.AccountDetailsNotFoundException;
import com.cg.mra.exceptions.InvalidAmountException;
import com.cg.mra.services.AccountService;
import com.cg.mra.services.AccountServiceImpl;
import junit.framework.Assert;

public class MobileRechargeApplicationTest {
	public static AccountService services;
	@BeforeClass
	public static void setUpTestEnv() {
		services = new AccountServiceImpl();
	}
	@Before
	public void setUpTestData() {
		Account account1 = new Account("9010210100" , "Prepaid" ,"Patit Pawan" , 200);
		Account account2 = new Account("9010210101" , "Prepaid" ,"Bibek Kumar" , 300);
		AccountDaoImpl.accountEntry.put(account1.getMobileNo(), account1);
		AccountDaoImpl.accountEntry.put(account2.getMobileNo(), account2);
	}
	@Test(expected=AccountDetailsNotFoundException.class)
	public void TestRechargeAccountForInvalidMobileNumber() throws AccountDetailsNotFoundException {
		services.rechargeAccount("9010210200", 100);
	}
	@Test
	public void TestRechargeAccountForValidMobileNumber() throws AccountDetailsNotFoundException, InvalidAmountException{
		double actualAmount = services.rechargeAccount("9010210100", 100);
		double expectedAmount = 300;
		Assert.assertEquals(expectedAmount, actualAmount);
	}
	@Test(expected=InvalidAmountException.class)
	public void TestRechargeAccountForValidMobileNumberWithInvalidRechargeAmount() throws AccountDetailsNotFoundException, InvalidAmountException{
		services.rechargeAccount("9010210100", -100);
	}
	@AfterClass
	public static void tearDownTestEnv() {
		services = null;
	}
}
