package com.cg.mra.services;

import com.cg.mra.beans.Account;
import com.cg.mra.exceptions.AccountDetailsNotFoundException;
import com.cg.mra.exceptions.ApplicationServicesDownException;
import com.cg.mra.exceptions.InvalidAmountException;

public interface AccountService {
	//Get Account Details For The Given MobileNo
	Account getAccountDetails(String mobileNo) throws AccountDetailsNotFoundException, ApplicationServicesDownException;
	//Recharge Account For The Given MobileNo and Update The Account Balance With Recharge Amount
	double rechargeAccount(String mobileNo, double rechargeAmount)throws AccountDetailsNotFoundException, InvalidAmountException, ApplicationServicesDownException;
	//Validate 10-digit MobileNo
	public boolean validateMobileNo(String mobileNo);
}
