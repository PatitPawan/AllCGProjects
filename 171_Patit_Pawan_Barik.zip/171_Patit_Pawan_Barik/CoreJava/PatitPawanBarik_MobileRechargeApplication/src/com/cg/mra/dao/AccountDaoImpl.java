package com.cg.mra.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.mra.beans.Account;

public class AccountDaoImpl implements AccountDao{
	public static Map<String,Account> accountEntry;   //Map is created as public, static for JUnit Testing 
	public AccountDaoImpl() {
		accountEntry = new HashMap<>(); //Created HashMap for DataStorage
		accountEntry.put("9010210122", new Account("Prepaid","Vaishali",200));
		accountEntry.put("9010210123", new Account("Prepaid","Megha",453));
		accountEntry.put("9010210124", new Account("Prepaid","Vikas",631));
		accountEntry.put("9010210125", new Account("Prepaid","Anju",521));
		accountEntry.put("9010210126", new Account("Prepaid","Tushar",632));
	}
	//Get Account Details For The Given MobileNo
	@Override
	public Account getAccountDetails(String mobileNo) { 
		return accountEntry.get(mobileNo);
	}
	//Recharge Account For The Given MobileNo and Update The Account Balance With Recharge Amount
	@Override
	public double rechargeAccount(String mobileNo, double rechargeAmount) {
		double newBalance = accountEntry.get(mobileNo).getAccountBalance() + rechargeAmount;
		accountEntry.get(mobileNo).setAccountBalance(newBalance);
		return newBalance;
	}

}
