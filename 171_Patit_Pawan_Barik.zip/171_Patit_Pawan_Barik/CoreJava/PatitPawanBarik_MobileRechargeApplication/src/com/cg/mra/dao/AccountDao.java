package com.cg.mra.dao;

import com.cg.mra.beans.Account;

public interface AccountDao {
	//Get Account Details For The Given MobileNo
	Account getAccountDetails(String mobileNo);
	//Recharge Account For The Given MobileNo and Update The Account Balance With Recharge Amount
	double rechargeAccount(String mobileNo, double rechargeAmount);
}
