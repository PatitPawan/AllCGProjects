package com.cg.payroll.test;

import java.util.ArrayList;
import java.util.List;
import org.easymock.EasyMock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.exceptions.AssociateDetailNotfoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.util.PayrollDBUtil;

public class PayrollServicesTestEasyMock {
	private static PayrollServices payrollServices;
	private static AssociateDAO mockAssociateDAO;
	@BeforeClass
	public static void setUpTestEnv() {
		mockAssociateDAO = EasyMock.mock(AssociateDAO.class);
		payrollServices = new PayrollServicesImpl(mockAssociateDAO);
	}
	@Before
	public void setUpTestData() {
		Associate associate1 = new Associate(101,78000,"Ram","kumar","SE","Analyst","ANNHDUH","suyg@gm",new Salary(35000, 1200, 1200),new BankDetails(5875, "SBI", "1653sbi"));
		Associate associate2 = new Associate(102,80000,"Shyam","kumar","SE","Analyst","DUH","dhfd@gm",new Salary(35000, 1200, 1200),new BankDetails(5555, "YBI", "1653sbi"));
		Associate associate3 = new Associate(102,80000,"Ghanshyam","kumar","SDE","Analyst","DUH","dd@gm",new Salary(35000, 1200, 1200),new BankDetails(5555, "TBI", "1653sbi"));
		ArrayList<Associate> associateList = new ArrayList<Associate>();
		associateList.add(associate1);
		associateList.add(associate2);
		EasyMock.expect(mockAssociateDAO.save(associate3)).andReturn(associate3);
		
		EasyMock.expect(mockAssociateDAO.findOne(101)).andReturn(associate1);
		EasyMock.expect(mockAssociateDAO.findOne(102)).andReturn(associate2);
		EasyMock.expect(mockAssociateDAO.findOne(1234)).andReturn(null);
		EasyMock.expect(mockAssociateDAO.findAll()).andReturn(associateList);
		EasyMock.replay(mockAssociateDAO);
	}
	@Test(expected = AssociateDetailNotfoundException.class)
		public void testGetAssociateDetailsForInvalidAssociateId() throws AssociateDetailNotfoundException{
			payrollServices.getAssociateDetails(1234);
			EasyMock.verify(mockAssociateDAO.findOne(1234));
	}
	@Test(expected = AssociateDetailNotfoundException.class)
	public void testGetAssociateDetailsForValidAssociateId() throws AssociateDetailNotfoundException{
		Associate expectedAssociate = new Associate(102,80000,"Shyam","kumar","SE","Analyst","DUH","dhfd@gm",new Salary(35000, 1200, 1200),new BankDetails(5555, "YBI", "1653sbi"));
		Associate actualAssociate = payrollServices.getAssociateDetails(102);
		Assert.assertEquals(expectedAssociate,actualAssociate);
	}
	@Test(expected = AssociateDetailNotfoundException.class)
	public void testAcceptAssociateDetails(){
		int expectedAssociateId = 103;
		int actualAssociateId =payrollServices.acceptAssociateDetails("Shyam","kumar","dhfd@gm","SE","Analyst","DUHhtt",80000,35000, 1200, 1200,5555, "YBI", "1653sbi");
		Assert.assertEquals(expectedAssociateId,actualAssociateId);
	}
	@Test(expected = AssociateDetailNotfoundException.class)
	public void testCalculateNetSalaryForValidAssociate(){
		int expectedNetSalary = 103;
		int actualNetSalary = payrollServices.calculateNetSalary(102);
		Assert.assertEquals(expectedNetSalary,actualNetSalary);
	}
	@Test(expected = AssociateDetailNotfoundException.class)
	public void testCalculateNetSalaryForInvalidAssociate(){
		int expectedId = 103;
		int actualId = payrollServices.calculateNetSalary(123);
		Assert.assertEquals(expectedId,actualId);
	}
	@Test(expected = AssociateDetailNotfoundException.class)
	public void testGetAllAssociateDetails(){
		Associate associate1 = new Associate(101,78000,"Ram","kumar","SE","Analyst","ANNHDUH","suyg@gm",new Salary(35000, 1200, 1200),new BankDetails(5875, "SBI", "1653sbi"));
		Associate associate2 = new Associate(102,80000,"Shyam","kumar","SE","Analyst","DUH","dhfd@gm",new Salary(35000, 1200, 1200),new BankDetails(5555, "YBI", "1653sbi"));
		ArrayList<Associate> expectedAssociateList = new ArrayList<Associate>();
		expectedAssociateList.add(associate1);
		expectedAssociateList.add(associate2);
		ArrayList<Associate>actualAssociateList = (ArrayList<Associate>) payrollServices.getAllAssociateDetails();
		Assert.assertEquals(expectedAssociateList, actualAssociateList);
	}
	@After
	public void tearDownTestData() {
		PayrollDBUtil.associates.clear();
		PayrollDBUtil.ASSOCIATE_ID_COUNTER=100;
	}
	@AfterClass
	public static void tearDownTestEnv(){
		payrollServices = null;
	}
}
