package com.cg.project.threadwork;

import com.cg.project.beans.Account;

public class Customer implements Runnable {
	public Customer(){	}
	private static Account account;
	static {
		account = new Account(10000);
		System.out.println("Initial Balance"+account.getBalance());
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++");
		
	}
	public void run(){
		Thread customerThread = Thread.currentThread();
		if(customerThread.getName().equals("Rahul")) {
			for(int i=1;i<11;i++) {
				try {
					System.out.println("Rahul call withdraw"+i+" time balance = "+account.withdraw(3000));
					Thread.sleep(2000);
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		else if(customerThread.getName().equals("Anil")) {
			for(int i=1;i<11;i++) {
				try {
					System.out.println("Anil call deposit"+i+" time balance = "+account.deposit(2000));
					Thread.sleep(2000);
				}catch (Exception e) {
					e.printStackTrace();
					}
			}
		}
		else if(customerThread.getName().equals("Satish")) {
			for(int i=1;i<11;i++) {
				System.out.println("Satish call deposit"+i+" time balance = "+account.checkBalance());
			}
		}
	}
}