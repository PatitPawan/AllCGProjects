package com.cg.mathproject.test;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.mathproject.exceptions.NegativeNumberException;
import com.cg.mathproject.services.MathServiceImpl;
import com.cg.mathproject.services.MathServices;

import junit.framework.Assert;

public class MathServicesTest {
	public static MathServices services;
	@BeforeClass
	public static void setUpTestEnv() {
		services = new MathServiceImpl();
	}
	@Test(expected=NegativeNumberException.class)
	public void testAddForFirstNegativeNumber() throws NegativeNumberException{
		services.add(-100, 200);
	}
	@Test(expected=NegativeNumberException.class)
	public void testAddForSecondNegativeNumber() throws NegativeNumberException{
		services.add(100, -200);
	}
	@Test(expected=NegativeNumberException.class)
	public void testAddForBothPositiveNumber() throws NegativeNumberException{
		Assert.assertEquals(300, services.add(100, 200));
	}
	@AfterClass
	public void tearDownTestEnv() {
		services = null;
	}
}
