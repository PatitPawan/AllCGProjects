package com.cg.mathproject.services;

import com.cg.mathproject.exceptions.NegativeNumberException;

public class MathServiceImpl implements MathServices{

	@Override
	public int add(int n1, int n2) throws NegativeNumberException {
		if(n1<0){
			throw new NegativeNumberException("1st Number Negative");
		}
		else if(n2<0){
			throw new NegativeNumberException("2nd Number Negative");
		}
		else if(n1<0||n2>0) {
			throw new NegativeNumberException("Both Numbers Negative");
		}
		return n1+n2;
	}

	@Override
	public int sub(int n1, int n2) throws NegativeNumberException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int div(int n1, int n2) throws NegativeNumberException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int mul(int n1, int n2) throws NegativeNumberException {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
