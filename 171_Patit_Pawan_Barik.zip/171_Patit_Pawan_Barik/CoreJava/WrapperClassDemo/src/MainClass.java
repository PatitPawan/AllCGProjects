
public class MainClass {

	public static void main(String[] args) {
		
		int num = 100;
		Integer iob = new Integer(num);
		Integer iob2 = iob+num+num+iob;
		num = iob2;
		int num2 = num+iob2;
		System.out.println("Result : "+iob2);
		System.out.println("Result : "+num2);
	}

}
