package com.cg.lambdastream.finterfaces;
@FunctionalInterface
public interface FIPower {
	int power(int x, int y);
}