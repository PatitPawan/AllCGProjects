package com.cg.banking.services;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.AccountDAOImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.util.BankingDBUtil;

public class BankingServicesImpl implements BankingServices{
	Scanner sc = new Scanner(System.in);
	private AccountDAO accountDao = new AccountDAOImpl();
	@Override
	public Account openAccount(String accountType, float initBalance)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		if(accountType==null) {
			throw new InvalidAccountTypeException("Invalid Account Type Selection.");
		}
		if(initBalance<500) {
			throw new InvalidAmountException("Invalid Amount for Opening Account.");
		}
		String accountStatus = "ACTIVE";
		long accountNo = BankingDBUtil.getACCOUNT_NO_COUNTER();
		int pinNumber = generatePinNumber(accountNo);
		Map<Long,Transaction> transactions = new HashMap<Long, Transaction>();
		Account account = new Account(accountNo, pinNumber, accountType, accountStatus,  initBalance, transactions);
		account = accountDao.save(account);
		return account;
	}
	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountBlockedException, AccountNotFoundException, BankingServicesDownException {
		Account account = getAccountDetails(accountNo);
		if(account==null){
			throw new AccountNotFoundException();
		}
		else if(account.getAccountStatus().equalsIgnoreCase("ACTIVE")){
			float newAmount = account.getAccountBalance() + amount;
			account.setAccountBalance(newAmount);
			long transactionId = BankingDBUtil.getTRANSACTION_ID_COUNTER();
			Transaction transaction = new Transaction(transactionId,amount,"Deposited");
			System.out.println("TID: "+transactionId);
			System.out.println("Trans: "+ transaction);
			System.out.println("AccBalance: "+account.getAccountBalance());
			account.getTransactions().put(transactionId, transaction);
		}
		else {
			System.out.println("Account is Blocked.");
		}
		return account.getAccountBalance();
	}
	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) throws InsufficientAmountException,
			AccountNotFoundException, AccountBlockedException, BankingServicesDownException, InvalidPinNumberException {
		Account account = getAccountDetails(accountNo);
		if(account==null){
			throw new AccountNotFoundException();
		}
		if(account.getAccountStatus().equalsIgnoreCase("ACTIVE")&& account.getAttempt()<=3){
			int attempt = account.getAttempt();
			if(account.getPinNumber()!=pinNumber){
				for(attempt=1;attempt<3;attempt++) {
					System.out.println("Pin Incorrect.");
					System.out.println("Enter Pin Again: ");
					pinNumber = sc.nextInt();
					if(account.getPinNumber()==pinNumber) {
						break;
					}
				}
				if(attempt>=3)
				{
					account.setAccountStatus("BLOCKED");
					throw new AccountBlockedException("Account Blocked due to 3 Unsuccessful Pin attempts.");
				}
			}
			if(account.getAccountBalance() - amount <500) {
				throw new InsufficientAmountException("Insufficient funds.");
			}
			else {
				account.setAccountBalance( account.getAccountBalance()-amount);
				account.setAttempt(0);
				long transactionId = BankingDBUtil.getTRANSACTION_ID_COUNTER();
				Transaction transaction = new Transaction(transactionId,amount,"Withdrawn");
				account.getTransactions().put(transactionId, transaction);
			}
		}
		return account.getAccountBalance();
	}
	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
		Account accTo = getAccountDetails(accountNoTo);
		Account accFrom = getAccountDetails(accountNoFrom);
		if(accTo==null || accFrom==null) {
			throw new AccountNotFoundException();
		}
		if(accFrom.getAccountStatus().equalsIgnoreCase("ACTIVE")&& accFrom.getAttempt()<=3){
			if(accFrom.getPinNumber()!=pinNumber){
				int attempt = accFrom.getAttempt();
				attempt++;
				accFrom.setAttempt(attempt);
				if(attempt>=3)
				{
					accFrom.setAccountStatus("BLOCKED");
				}
			}
			if(accFrom.getAccountBalance() - transferAmount <500) {
				throw new InsufficientAmountException("Insufficient funds.");
			}
			else {
				accFrom.setAccountBalance((accFrom.getAccountBalance() - transferAmount));
				accTo.setAccountBalance((accFrom.getAccountBalance() + transferAmount));
				accFrom.setAttempt(0);
				long transactionId = BankingDBUtil.getTRANSACTION_ID_COUNTER();
				Transaction transactionTo = new Transaction(transactionId,transferAmount,"Deposited");
				Transaction transactionFrom = new Transaction(transactionId,transferAmount,"Withdrawn");
				accFrom.getTransactions().put(transactionId, transactionFrom);
				accTo.getTransactions().put(transactionId, transactionTo);
			}
		}
		return false;
	}
	@Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServicesDownException {
		Account account = accountDao.findOne(accountNo);
		if(account==null)
			throw new AccountNotFoundException("Account  "+accountNo +" not found.");
		return account;
	}
	@Override
	public List<Account> getAllAccountDetails() throws BankingServicesDownException {
		return accountDao.findAll();
	}
	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountBlockedException {
		Account account = accountDao.findOne(accountNo);
		ArrayList<Transaction> transactionList =(ArrayList<Transaction>) account.getTransactions().values();
		return transactionList;
	}
	@Override
	public int generatePinNumber(long accountNo) throws BankingServicesDownException {
		int pinNumber = (int)(Math.random()*10000);
		return pinNumber;
	}
	@Override
	public int setNewPinNumber(long accountNo) throws AccountNotFoundException, BankingServicesDownException {
		Account account = accountDao.findOne(accountNo);
		int pinNumber = account.getPinNumber();
		System.out.println("Input New PIN Number : ");
		int pinNumber1 = sc.nextInt();
		System.out.println("Confirm New PIN Number : ");
		int pinNumber2 = sc.nextInt();
		if(pinNumber1==pinNumber2) {
			pinNumber = pinNumber1;
			account.setPinNumber(pinNumber);
			System.out.println("Successful PIN changed.");
		}
		else {
			System.out.println("PIN mismatch.");
		}
		return 0;
	}
}
