package com.cg.banking.util;
import java.util.HashMap;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
public class BankingDBUtil {
	public static HashMap<Long,Account> accounts = new HashMap<>();
	public static long ACCOUNT_NO_COUNTER = 100000;
	public static long TRANSACTION_ID_COUNTER = 100;
	public static long getACCOUNT_NO_COUNTER()
	{
		return ++ACCOUNT_NO_COUNTER;
	};
	public static long getTRANSACTION_ID_COUNTER()
	{
		return ++TRANSACTION_ID_COUNTER;
	};
}
