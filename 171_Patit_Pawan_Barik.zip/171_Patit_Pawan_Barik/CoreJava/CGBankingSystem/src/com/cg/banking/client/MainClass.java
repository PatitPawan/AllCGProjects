package com.cg.banking.client;

import java.util.Scanner;

import com.cg.banking.beans.Account;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {
 public static void main(String [] args) {
	BankingServices  bankService = new BankingServicesImpl();
	Scanner sc = new Scanner(System.in);
//	Account account = bankService.openAccount("Savings", 1000);
	int choice =0;
	long accountNo;
	boolean flag = true;
	while(flag==true) {
		System.out.println("1: Open Account \n2: Deposit Amount \n3: Withdraw Amount \n4: Funds Transfer \n5: Generate New PIN Number \n6: Exit\n");
		System.out.println("Enter Choice: ");
		choice = sc.nextInt();
		switch(choice)
		{
		case 1: System.out.println("1:Savings\t 2:Current \nEnter Type:");
			int accType = sc.nextInt();
			int amount;
			switch(accType)
			{
			case 1:
				System.out.println("Enter Initial Balance");
				amount = sc.nextInt();
				System.out.println(bankService.openAccount("Savings", amount));
				break;
			case 2:
				System.out.println("Enter Initial Balance");
				amount = sc.nextInt();
				System.out.println(bankService.openAccount("Current", amount));
				break;
			default: System.out.println("Wrong Choice");
			}
			break;
		case 2: 
			System.out.println("Enter Account Number: ");
			accountNo = sc.nextLong();
			System.out.println("Enter Amount: ");
			amount = sc.nextInt();
			System.out.println(bankService.depositAmount(accountNo, amount));
			break;
		case 3: 
			System.out.println("Enter Account Number: ");
			accountNo = sc.nextLong();
			System.out.println("Enter Amount: ");
			amount = sc.nextInt();
			System.out.println("Enter Pin Number: ");
			int pinNumber = sc.nextInt();
			System.out.println(bankService.withdrawAmount(accountNo, amount, pinNumber));
			break;
		case 4: 
			System.out.println("Enter Your Account Number: ");
			long accountNoFrom = sc.nextLong();
			System.out.println("Enter Amount: ");
			amount = sc.nextInt();
			System.out.println("Enter To Account Number: ");
			long accountNoTo = sc.nextLong();
			System.out.println("Enter Pin Number: ");
			pinNumber = sc.nextInt();
			System.out.println(bankService.fundTransfer(accountNoTo, accountNoFrom, amount, pinNumber));
			break;
		case 5:
			System.out.println("Enter Your Account Number: ");
			accountNo = sc.nextLong();
			bankService.setNewPinNumber(accountNo);
			System.out.println(bankService.getAccountDetails(accountNo));
			break;
		case 6:
			flag = false;
			System.out.println("Exit Application.");
			break;
		default: System.out.println("Wrong Choice");
		}	
	}
 }
}
