package com.cg.banking.daoservices;
import java.util.ArrayList;
import java.util.List;
import com.cg.banking.beans.Transaction;
import com.cg.banking.util.BankingDBUtil;

public class TransactionDAOImpl implements TransactionDAO{
	@Override
	public Transaction save(Transaction transaction) {
		transaction.setTransactionId(BankingDBUtil.getTRANSACTION_ID_COUNTER());
		//BankingDBUtil.accounts.put(transaction.getTransactionId(), transaction);
		return transaction;
	}
	@Override
	public boolean update(Transaction transaction) {
		return false;
	}
	@Override
	public Transaction findOne(int transactionId) {
//		return BankingDBUtil.accounts.get());
	return null;
	}
	@Override
	public List<Transaction> findAll() {
//		ArrayList<Transaction>transactionList = new ArrayList<Transaction>(BankingDBUtil.accounts.values());
//		return transactionList;
		return null;
	}
}
