package com.equalsdemo.client;

import com.equalsdemo.beans.Employee;

public class MainClass {

	public static void main(String[] args) {
		Employee  e1 = new Employee(1,"PPB","Barik",15000);
		Employee  e2 = new Employee(1,"PPB","Barik",15000);
		Object obj = e2;
		System.out.println(e1.equals(e2));
		System.out.println(obj.equals(e2));
		System.out.println(obj.equals(e1));
	}

}
