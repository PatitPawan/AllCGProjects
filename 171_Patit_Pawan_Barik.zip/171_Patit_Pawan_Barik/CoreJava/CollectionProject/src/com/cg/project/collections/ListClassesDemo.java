package com.cg.project.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;

public class ListClassesDemo {
	public static void arrayListClassDemo(){
		ArrayList<String> strList = new ArrayList<>();
		//add
		strList.add("Satish");
		strList.add("Mahesh");
		strList.add("Suresh");
		strList.add("Nilesh");
		strList.add("Mayur");
		strList.add("Satish");
		
		System.out.println(strList);
		
		//search
		String nameToBeSearched = "Mayur";
		System.out.println(strList.contains(nameToBeSearched));
		//remove
		//sorting
		
		ArrayList<Associate> associates = new ArrayList<>();
		associates.add(new Associate(111,"Satish","Kumar",15000));
		associates.add(new Associate(112,"Ratish","Kumar",16000));
		associates.add(new Associate(113,"Matish","Kumar",17000));
		
		System.out.println(associates);
		
		Associate associateToBeSearched = new Associate(112,"Ratish","Kumar",16000);
		
		System.out.println(associates.contains(associateToBeSearched));
		
		//sorting
		Collections.sort(associates);
		for(Associate associate : associates)
		{
			System.out.println(associate);
		}
		System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
		
		Collections.sort(associates, new AssociateComparator());
		
		for(Associate associate : associates)
		{
			System.out.println(associate);
		}
	}
	public static void LinkedListDemo (){
		LinkedList<String> strList = new LinkedList<String>();
		//add
		strList.add("Satish");
		strList.add("Mahesh");
		strList.add("Suresh");
		strList.add("Nilesh");
		strList.add("Mayur");
		strList.add("Satish");
		
		System.out.println(strList);
		
		//search
		String nameToBeSearched = "Mayur";
		System.out.println(strList.contains(nameToBeSearched));
		//remove
		//sorting
		
		LinkedList<Associate> associates = new LinkedList<Associate>();
		associates.add(new Associate(111,"Satish","Kumar",15000));
		associates.add(new Associate(112,"Ratish","Kumar",16000));
		associates.add(new Associate(113,"Matish","Kumar",17000));
		
		System.out.println(associates);
		
		Associate associateToBeSearched = new Associate(112,"Ratish","Kumar",16000);
		
		System.out.println(associates.contains(associateToBeSearched));
		
		//sorting
		Collections.sort(associates);
		for(Associate associate : associates)
		{
			System.out.println(associate);
		}
		System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
		
		Collections.sort(associates, new AssociateComparator());
		
		for(Associate associate : associates)
		{
			System.out.println(associate);
		}
	}

}
