package com.cg.project.collections;

import java.util.HashSet;

public class SetClassDemo {
	public static void hashSetClassDemo(){
	HashSet<Associate> associates = new HashSet<>();
	associates.add(new Associate(111,"Satish","Kumar",15000));
	associates.add(new Associate(112,"Ratish","Kumar",16000));
	associates.add(new Associate(113,"Matish","Kumar",17000));
	}
}
