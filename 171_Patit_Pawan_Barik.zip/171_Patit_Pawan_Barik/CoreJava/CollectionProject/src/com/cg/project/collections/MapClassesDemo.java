package com.cg.project.collections;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Set;

public class MapClassesDemo {
	public static void hashTableClassDemo(){
		Hashtable<Integer,Associate> associates = new Hashtable<>();
		associates.put(111,new Associate(111,"Satish","Kumar",15000));
		associates.put(112,new Associate(112,"Ratish","Kumar",16000));
		associates.put(113,new Associate(113,"Matish","Kumar",17000));
		associates.put(112,new Associate(112,"Natish","Kumar",18000));
		Associate associate = associates.get(112);
		associates.remove(113);
		Set<Integer> keys = associates.keySet();
		for(Integer key: keys)
		{
			System.out.println(associates.get(key));
		}
		ArrayList<Associate> associateList = new ArrayList<>(associates.values());
	}
}
