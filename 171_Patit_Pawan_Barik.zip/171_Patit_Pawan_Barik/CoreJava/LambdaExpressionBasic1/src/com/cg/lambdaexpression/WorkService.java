package com.cg.lambdaexpression;

public interface WorkService {
	public void doSomeWork();
}
