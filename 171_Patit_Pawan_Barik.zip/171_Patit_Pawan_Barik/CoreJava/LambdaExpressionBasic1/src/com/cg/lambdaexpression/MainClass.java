package com.cg.lambdaexpression;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Stream;

import com.cg.beans.Employee;
import com.cg.lambdainterface.FunctionalInterface1;
import com.cg.lambdainterface.FunctionalInterface2;

public class MainClass {

	public static void main(String[] args) {
//		WorkService services = new WorkService() {
//		public void doSomeWork() {
//			System.out.println("Work in Progress.");
//		}
//	};
//	services.doSomeWork();
//	WorkService services2 = ()->{
//		System.out.println("Work in Progress.");
//		System.out.println("Work Done.");
//	};
//	services2.doSomeWork();
//		WorkService service2 = () -> WorkService services = new WorkService() 
//		callForWork(service2);
//		callForWork(()->WorkService services = new WorkService());
//	};
//	FunctionalInterface1 ref1 = (firstName,lastName)->System.out.println("Good Afternoon"+firstName+lastName);
//	ref1.greetUser("PP","Barik");
//
//	FunctionalInterface2 ref2 = (a,b)->a+b;
//	ref2.add(155,255);
//	}
//	public static void callForWork(WorkService service) {
//		service.doSomeWork();		
//	}
		ArrayList<Employee> empList = new ArrayList<Employee>();
		empList.add(new Employee(101,15000,"Aashish"));
		empList.add(new Employee(102,16000,"Kashish"));
		empList.add(new Employee(103,18000,"Rashish"));
		empList.add(new Employee(104,14000,"Khashish"));
		empList.add(new Employee(105,19000,"Pashish"));
		Comparator<Employee> comparator = (emp1,emp2)->emp1.getBasicSalary() - emp2.getBasicSalary();
		Collections.sort(empList,comparator);
		Collections.sort(empList,(emp1,emp2)->emp1.getBasicSalary() - emp2.getBasicSalary());
		
		printEmployeeDetailsPredicate(empList,(employee)->employee.getEmpName().startsWith("K"));
		System.out.println("-----------------------------------------------------------------------------------------------------------------");
		printEmployeeDetailsPredicate(empList,(employee)->{
			if(employee.getBasicSalary()>10000) return true;
			else return false;
		});
		
		Stream<Employee> stream1 = empList.stream(); 
		Stream<Employee> stream2 = stream1.distinct(); 
		Stream<Employee> stream3 = stream2.filter((employee)->employee.getEmpName().startsWith("N")); 
		System.out.println(stream3.count());
		stream3.forEach(employee->System.out.println(employee));
		empList.stream()
		.distinct()
		.filter((employee)->employee.getEmpName().startsWith("N"))
		.forEach(employee->System.out.println(employee));
		System.out.println(empList.stream().map(employee->employee.getBasicSalary()));
	}
	private static void printEmployeeDetailsPredicate(List<Employee>empList, Predicate<Employee>condition) {
		for(Employee employee:empList)
			if(condition.test(employee))
				System.out.println(employee);
		
	}
}
