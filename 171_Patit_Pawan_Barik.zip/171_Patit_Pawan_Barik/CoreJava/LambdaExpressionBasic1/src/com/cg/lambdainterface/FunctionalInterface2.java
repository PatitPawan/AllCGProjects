package com.cg.lambdainterface;

public interface FunctionalInterface2 {
	int add(int a, int b);
}
