package com.cg.lambdainterface;

public interface FunctionalInterface1 {
	void greetUser(String firstName,String lastName);
}
