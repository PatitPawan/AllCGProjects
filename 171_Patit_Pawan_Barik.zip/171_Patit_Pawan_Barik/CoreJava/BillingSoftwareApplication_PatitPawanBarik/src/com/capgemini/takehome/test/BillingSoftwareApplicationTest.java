package com.capgemini.takehome.test;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.capgemini.takehome.beans.Product;
import com.capgemini.takehome.exceptions.ProductDetailsNotFoundException;
import com.capgemini.takehome.service.IProductService;
import com.capgemini.takehome.service.ProductService;

import junit.framework.Assert;

public class BillingSoftwareApplicationTest {
	public static IProductService services;
	@BeforeClass
	public static void setUpEnv() {
		services = new ProductService();
	}
	@Before
	public void setTestData()	{
		
	}
	@Test(expected = ProductDetailsNotFoundException.class)
	public void testGetProductDetailsForInvalidInput(int productCode) throws ProductDetailsNotFoundException{
		services.getProductDetails(productCode);
	}
	@Test
	public void testGetProductDetailsForValidInput(int productCode) throws ProductDetailsNotFoundException{
		Product actualproduct = services.getProductDetails(1002);
		Product expectedProduct = new Product(1002,"LEDTV","Electronics",45000);
		Assert.assertEquals(expectedProduct, actualproduct);
	}
	@Test
	public void testCalculateTotalBillForValidInput(int productCode, int quantity) throws ProductDetailsNotFoundException{
		int actualPrice= services.calculateTotalBill(1002, 1);
		int expectedPrice = 45000;
		Assert.assertEquals(expectedPrice, actualPrice);
	}
	@After
	public void tearDownTestData()	{
		
	}
	@AfterClass
	public static void tearDownEnv() {
		services = new ProductService();
	}
}
