package com.cg.project.threadwork;

public class RunnableResource implements Runnable{
	@Override
	public void run() {
		Thread t = Thread.currentThread();
//		if(t.getName().equals("oddThread"))
//			for(int i=1;i<100;i+=2) {
//				System.out.println(i + " "+ t.getName());
//		}
//		if(t.getName().equals("evenThread"))
//			for(int i=0;i<100;i+=2) {
//				System.out.println(i + " "+ t.getName());
//		}
//		if(t.getName().equals("primeThread"))
//			for(int i=1;i<100;i++) {
//				boolean flag = true;
//				for(int j=2;j<=i/2;j++)
//				{
//					if(i%j==0)
//						{
//							flag = false;
//							break;
//						}
//				}
//				if(flag==true) {
//					System.out.println(i + " "+ t.getName());
//				}
//		}
		if(t.getName().equals("tickThread"))
			for(int i=1;i<10;i++) {
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				System.out.println("Tick  "+i + " "+ t.getName());
			}
		if(t.getName().equals("tockThread"))
			for(int i=1;i<10;i++) {
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				System.out.println("Tick  "+i + " "+ t.getName());
			}
		System.out.println("End of thread task");
	}
}
