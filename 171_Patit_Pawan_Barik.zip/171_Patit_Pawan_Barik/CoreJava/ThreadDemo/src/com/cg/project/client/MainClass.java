package com.cg.project.client;

import com.cg.project.threadwork.MyThread;
import com.cg.project.threadwork.RunnableResource;

public class MainClass {
	public static void main(String [] args) throws InterruptedException {
//		MyThread th1 = new MyThread("thickThread");
//		MyThread th2 = new MyThread("thinThread");
//		th1.start();
//		th2.start();
		
//		RunnableResource resources = new RunnableResource();
//		Thread th1 = new Thread(resources,"evenThread");
//		Thread th2 = new Thread(resources,"oddThread");
//		Thread th3 = new Thread(resources,"primeThread");
//		th1.start();
//		th2.start();
//		th3.start();
		
		RunnableResource resources = new RunnableResource();
		Thread th1 = new Thread(resources,"tickThread");
		Thread th2 = new Thread(resources,"tockThread");
		th1.start();
		th1.join();
		th2.start();
		System.out.println("End of main()");
	}	
}
