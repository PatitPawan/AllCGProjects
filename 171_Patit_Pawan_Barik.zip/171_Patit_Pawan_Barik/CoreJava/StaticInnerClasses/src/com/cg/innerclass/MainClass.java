package com.cg.innerclass;
public class MainClass {
	StaticInnerClassDemo.VegKitchen vegKitchen = new StaticInnerClassDemo.VegKitchen();
	StaticInnerClassDemo.NonVegKitchen nonVegKitchen = new StaticInnerClassDemo.NonVegKitchen();
}
