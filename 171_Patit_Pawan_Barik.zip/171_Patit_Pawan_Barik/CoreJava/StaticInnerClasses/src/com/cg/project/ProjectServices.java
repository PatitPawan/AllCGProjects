package com.cg.project;

public interface ProjectServices {
	public void devleopProject();
}
