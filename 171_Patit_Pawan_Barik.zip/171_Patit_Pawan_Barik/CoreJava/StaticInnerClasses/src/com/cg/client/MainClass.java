package com.cg.client;
import com.cg.project.ProjectServices;

public class MainClass {
	public static void main(String args) {
		ProjectServices services = new ProjectServices() {
			@Override
			public void devleopProject() {
				System.out.println("IT project has developed.");
			}
		};
	}
}
