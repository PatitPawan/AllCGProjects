package com.cg.project.stepdefinition;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TempStepDefinition {
	@Given("^user is on the login page of github\\.com in browser$")
	public void user_is_on_the_login_page_of_github_com_in_browser() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
	@When("^user enter credentials in Username and Password$")
	public void user_enter_credentials_in_Username_and_Password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
	@Then("^user views the login page asking to re-enter credentials$")
	public void user_views_the_login_page_asking_to_re_enter_credentials() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
	@Then("^user views the github dashboard$")
	public void user_views_the_github_dashboard() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
}
