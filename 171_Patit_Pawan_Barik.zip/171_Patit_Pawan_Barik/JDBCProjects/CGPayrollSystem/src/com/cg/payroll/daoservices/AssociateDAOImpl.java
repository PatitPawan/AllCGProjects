package com.cg.payroll.daoservices;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.util.PayrollDBUtil;
public class AssociateDAOImpl  implements AssociateDAO{
	private static Connection con = PayrollDBUtil.getDBConnection();
	@Override
	public Associate save(Associate associate) {
		try {
			con.setAutoCommit(false);
			PreparedStatement pstmt1 = con.prepareStatement("Insert into Associate( associateId,yearlyInvestmentUnder80c, firstName, lastName, department, designation, pancard, emailId) values(Associate_Id_Seq.NEXTVAL,?,?,?,?,?,?,?)");
			pstmt1.setInt(1, associate.getYearlyInvestmentUnder80c());
			pstmt1.setString(2, associate.getFirstName());
			pstmt1.setString(3, associate.getLastName());
			pstmt1.setString(4, associate.getDepartment());
			pstmt1.setString(5, associate.getDesignation());
			pstmt1.setString(6, associate.getPancard());
			pstmt1.setString(7, associate.getEmailId());
			
			pstmt1.executeUpdate();
			
			PreparedStatement pstmt2 = con.prepareStatement("Select max(associateId) from Associate");
			ResultSet rs = pstmt2.executeQuery();
			rs.next();
			int associateId = rs.getInt(1);
			
			PreparedStatement pstmt3 = con.prepareStatement("Insert into Salary(associateId, basicSalary, epf,companyPf) values(?,?,?,?)");
			pstmt3.setInt(1,associateId);
			pstmt3.setInt(2,associate.getSalary().getBasicSalary());
			pstmt3.setInt(3,associate.getSalary().getEpf());
			pstmt3.setInt(4,associate.getSalary().getCompanyPf());
			pstmt3.executeUpdate();
			
			PreparedStatement pstmt4 = con.prepareStatement("Insert into Bank_Details(associateId, accountNumber, bankName,ifscCode) values(?,?,?,?)");
			pstmt4.setInt(1,associateId);
			pstmt4.setInt(2,associate.getBankDetails().getAccountNumber());
			pstmt4.setString(3,associate.getBankDetails().getBankName());
			pstmt4.setString(4,associate.getBankDetails().getIfscCode());
			pstmt4.executeUpdate();
			
			associate.setAssociateId(associateId);
			
			con.commit();
		}catch(SQLException e) {
			e.printStackTrace();
			try {
				con.rollback();
			}catch(SQLException e1) {
				e1.printStackTrace();
			}
		}
		return associate;
	}
	@Override
	public boolean update(Associate associate) {
		try {
			PreparedStatement pstmt1 = con.prepareStatement("Update Salary set HRA  = ? ,conveyenceAllowance = ?,otherAllowance = ?,personalAllowance =? ,monthlyTax = ?,grossSalary =? ,netSalary = ? where associateId = "+associate.getAssociateId());
			pstmt1.setInt(1,associate.getSalary().getHra());
			pstmt1.setInt(2,associate.getSalary().getConveyenceAllowance());
			pstmt1.setInt(3,associate.getSalary().getOtherAllowance());
			pstmt1.setInt(4,associate.getSalary().getPersonalAllowance());
			pstmt1.setInt(5,associate.getSalary().getMonthlyTax());
			pstmt1.setInt(6,associate.getSalary().getGrossSalary());
			pstmt1.setInt(7,associate.getSalary().getNetSalary());
			pstmt1.executeUpdate();
			return true;
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	@Override
	public Associate findOne(int associateId) {
		try {
			PreparedStatement pstmt1 = con.prepareStatement("Select * from Associate where associateId = "+associateId);
			ResultSet associateRs = pstmt1.executeQuery();
			if(associateRs.next()) {
				int yearlyInvestmentUnder80c = associateRs.getInt("yearlyInvestmentUnder80c");
				String firstName = associateRs.getString("firstName");
				String lastName = associateRs.getString("lastName");
				String department = associateRs.getString("department");
				String designation = associateRs.getString("designation");
				String pancard = associateRs.getString("pancard");
				String emailId = associateRs.getString("emailId");
				Associate associate = new Associate(associateId, yearlyInvestmentUnder80c, firstName, lastName, department, designation, pancard, emailId,null,null);
				
				PreparedStatement pstmt2 = con.prepareStatement("Select * from Salary where associateId = "+associateId);
				ResultSet salaryRs = pstmt2.executeQuery();
				salaryRs.next();
				int basicSalary = salaryRs.getInt("basicSalary");
				int hra= salaryRs.getInt("hra");
				int conveyenceAllowance = salaryRs.getInt("conveyenceAllowance");
				int otherAllowance = salaryRs.getInt("otherAllowance");
				int personalAllowance = salaryRs.getInt("personalAllowance");
				int monthlyTax = salaryRs.getInt("monthlyTax");
				int epf = salaryRs.getInt("epf"); 
				int companyPf = salaryRs.getInt("companyPf");
				int grossSalary = salaryRs.getInt("grossSalary");
				int netSalary = salaryRs.getInt("netSalary");
				Salary salary = new Salary(basicSalary, hra, conveyenceAllowance, otherAllowance, personalAllowance, monthlyTax, epf, companyPf, grossSalary, netSalary);
				
				PreparedStatement pstmt3 = con.prepareStatement("Select * from Bank_Details where associateId = "+associateId);
				ResultSet bankDetailsRs = pstmt3.executeQuery();
				bankDetailsRs.next();
				int accountNumber = bankDetailsRs.getInt("accountNumber");
				String bankName = bankDetailsRs.getString("bankName"); 
				String ifscCode = bankDetailsRs.getString("ifscCode");
				BankDetails  bankDetails = new BankDetails(accountNumber, bankName, ifscCode);
				associate.setSalary(salary);
				associate.setBankDetails(bankDetails);
				return associate;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	@Override
	public List<Associate> findAll() {
		ArrayList< Associate> associates = new ArrayList<Associate>();
		try {
			PreparedStatement pstmt1 = con.prepareStatement("Select * from Associate");
			ResultSet associateRs = pstmt1.executeQuery();
			while(associateRs.next()) {
				int associateId = associateRs.getInt("associateId");
				int yearlyInvestmentUnder80c = associateRs.getInt("yearlyInvestmentUnder80c");
				String firstName = associateRs.getString("firstNaSme");
				String lastName = associateRs.getString("lastName");
				String department = associateRs.getString("department");
				String designation = associateRs.getString("designation");
				String pancard = associateRs.getString("pancard");
				String emailId = associateRs.getString("emailId");
				Associate associate = new Associate(associateId, yearlyInvestmentUnder80c, firstName, lastName, department, designation, pancard, emailId,null,null);
				
				PreparedStatement pstmt2 = con.prepareStatement("Select * from Salary where associateId = "+associateId);
				ResultSet salaryRs = pstmt2.executeQuery();
				salaryRs.next();
				int basicSalary = salaryRs.getInt("basicSalary");
				int hra= salaryRs.getInt("hra");
				int conveyenceAllowance = salaryRs.getInt("conveyenceAllowance");
				int otherAllowance = salaryRs.getInt("otherAllowance");
				int personalAllowance = salaryRs.getInt("personalAllowance");
				int monthlyTax = salaryRs.getInt("monthlyTax");
				int epf = salaryRs.getInt("epf"); 
				int companyPf = salaryRs.getInt("companyPf");
				int grossSalary = salaryRs.getInt("grossSalary");
				int netSalary = salaryRs.getInt("netSalary");
				Salary salary = new Salary(basicSalary, hra, conveyenceAllowance, otherAllowance, personalAllowance, monthlyTax, epf, companyPf, grossSalary, netSalary);
				
				PreparedStatement pstmt3 = con.prepareStatement("Select * from Bank_Details where associateId = "+associateId);
				ResultSet bankDetailsRs = pstmt3.executeQuery();
				bankDetailsRs.next();
				int accountNumber = bankDetailsRs.getInt("accountNumber");
				String bankName = bankDetailsRs.getString("bankName"); 
				String ifscCode = bankDetailsRs.getString("ifscCode");
				BankDetails  bankDetails = new BankDetails(accountNumber, bankName, ifscCode);
				associate.setSalary(salary);
				associate.setBankDetails(bankDetails);
				associates.add(associate);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return associates;
	}
}
