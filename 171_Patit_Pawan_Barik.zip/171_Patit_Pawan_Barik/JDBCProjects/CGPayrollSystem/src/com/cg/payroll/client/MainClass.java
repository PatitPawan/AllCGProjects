package com.cg.payroll.client;
import java.util.List;
import java.util.Scanner;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

public class MainClass {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PayrollServices services = new PayrollServicesImpl();
		
//		Associate associateDetails = services.getAssociateDetails();
//		PayrollServices ser1 = new PayrollServicesImpl();
//		List<Associate> allAssociateDetails = ser1.getAllAssociateDetails();
//		System.out.println(allAssociateDetails);
		int choice = 0;
		boolean flag = true;
		while(flag) {
			System.out.println("Services:\n");
			System.out.println("1: Accept Associate Details \t 2:Get Associate Details\t 3:Calculate Net Salary \t 4:Get All Associates \t 5:Exit\n");
			System.out.println("Enter choice: ");
			choice = sc.nextInt();
			switch(choice) {
				case 1: 
					System.out.println("Enter Associate First Name: ");
					String fname = sc.next();
					System.out.println("Enter Associate Last Name: ");
					String lname = sc.next();
					System.out.println("Enter Associate Email ID: ");
					String emailId = sc.next();
					System.out.println("Enter Associate Department: ");
					String dept = sc.next();
					System.out.println("Enter Associate Designation: ");
					String desg = sc.next();
					System.out.println("Enter Associate PAN number: ");
					String panNo = sc.next();
					System.out.println("Enter Associate Yearly 80C Investment: ");
					int yearly80c = sc.nextInt();
					System.out.println("Enter Associate Basic Salary: ");
					int basicSal = sc.nextInt();
					System.out.println("Enter Associate EPF: ");
					int epf = sc.nextInt();
					System.out.println("Enter Associate CompanyPF: ");
					int cpf= sc.nextInt();
					System.out.println("Enter Associate Bank Account Number: ");
					int accNo = sc.nextInt();
					System.out.println("Enter Associate Bank Name: ");
					String bankName = sc.next();
					System.out.println("Enter Associate Bank IFSC Code: ");
					String bankIfsc = sc.next();
					System.out.println("Associate ID: "+services.acceptAssociateDetails(fname, lname, emailId, dept, desg, panNo, yearly80c, basicSal, epf, cpf, accNo, bankName, bankIfsc));
					break;
				case 2:
					System.out.println("Enter Associate Id to Search:");
					int associateId = sc.nextInt();
					System.out.println("Associate: "+services.getAssociateDetails(associateId));
					break;
				case 3:
					System.out.println("Enter Associate Id to Calculate Net Salary:");
					associateId = sc.nextInt();
					System.out.println("Net Salary :"+services.calculateNetSalary(associateId));
					break;
				case 4:
					System.out.println("All Associates: ");
					System.out.println(services.getAllAssociateDetails());
					break;
				case 5: 
					flag = false;
					break;
				default : System.out.println("Wrong Choice. Try Again.");
			}
		}
	}

}
