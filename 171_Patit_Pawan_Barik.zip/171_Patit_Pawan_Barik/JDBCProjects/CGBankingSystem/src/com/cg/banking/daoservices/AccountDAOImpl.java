package com.cg.banking.daoservices;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.cg.banking.beans.Account;
import com.cg.banking.util.BankingDBUtil;
public class AccountDAOImpl implements AccountDAO{
	private static Connection con = BankingDBUtil.getDBConnection();
	@Override
	public Account save(Account account) {
		try {
			con.setAutoCommit(false);
			PreparedStatement pstmt1 = con.prepareStatement("Insert into Account (accountNo,pinnumber,accounttype,accountstatus,accountbalance,attempt) values(Account_No_Seq.NEXTVAL,?,?,?,?,?)");
			pstmt1.setInt(1, account.getPinNumber());
			pstmt1.setString(2, account.getAccountType());
			pstmt1.setString(3, account.getAccountStatus());
			pstmt1.setFloat(4, account.getAccountBalance());
			pstmt1.setInt(5, account.getAttempt());
			pstmt1.executeUpdate();
			
			PreparedStatement pstmt2 = con.prepareStatement("Select max(accountNo) from Account");
			ResultSet rs = pstmt2.executeQuery();
			rs.next();
			int accountNo = rs.getInt(1);
			con.commit();
		}catch(SQLException e) {
			e.printStackTrace();
			try {
				con.rollback();
			}catch(SQLException e1) {
				e1.printStackTrace();
			}
		}
		return account;
	}
	@Override
	public boolean update(Account account) {
		return false;
	}
	@Override
	public Account findOne(long accountNo) {
		return null;
	}
	@Override
	public List<Account> findAll() {
		ArrayList<Account> accountList = new ArrayList<Account>(BankingDBUtil.accounts.values());
		return accountList;
	}
}
