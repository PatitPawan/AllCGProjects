package com.cg.banking.test;

import java.util.HashMap;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class BankingServicesTest {
	public static BankingServices services;
	@BeforeClass
	public static void setUpTestEnv() {
		services = new BankingServicesImpl();
	}
	@Before
	public void setUpTestData()
	{
		Transaction transactionAcc1 = new Transaction(100002,1000,"Deposit");
		Transaction transactionAcc2 = new Transaction(100003,1000,"Deposit");
		Map<Long,Transaction> transaction1 = new HashMap<Long, Transaction>();
		Map<Long,Transaction> transaction2 = new HashMap<Long, Transaction>();
		transaction1.put(100001L, transactionAcc1);
		transaction2.put(100001L, transactionAcc2);
		Account account1 = new Account(100002, 1233, "Savings", "Active", 2000, transaction1);
		Account account2 = new Account(100003, 1234, "Savings", "Active", 12000, transaction2);
	}
	@Test(expected = InvalidAccountTypeException.class)
	public void testOpenAccountForInvalidData() throws InvalidAccountTypeException, InvalidAmountException{
		long expectedAccountId = 100004;
		Account account1 = services.openAccount("Savings", 1200);
		long actualAccountId = account1.getAccountNo();
		Assert.assertEquals(expectedAccountId, actualAccountId);
	}
	@Test(expected = AccountNotFoundException.class)
	public void testDepositAmountForInvalidData() throws AccountNotFoundException{
		float balance = services.depositAmount(100000, 1200);
	}
	@Test(expected = InvalidAccountTypeException.class)
	public void testDepositAmountForValidData() throws InvalidAccountTypeException, InvalidAmountException{
		float expectedBalance = services.depositAmount(100002, 1200);
		float actualBalance = 2400;
		Assert.assertEquals(expectedBalance, actualBalance);
	}
	@Test(expected = AccountNotFoundException.class)
	public void testWithdrawAmountForValidData() throws InvalidAccountTypeException, InvalidAmountException{
		float expectedBalance = services.withdrawAmount(100002, 200,1233);
		float actualBalance = 1000;
		Assert.assertEquals(expectedBalance, actualBalance);
	}
	@Test(expected = AccountNotFoundException.class)
	public void testFundsTransferForValidData() throws AccountNotFoundException, InvalidAmountException, InvalidPinNumberException{
		services.fundTransfer(100002, 100003, 1000, 1234);
		float actualBalance = services.getAccountDetails(100002).getAccountBalance();
		float expectedBalance =3000;
		Assert.assertEquals(expectedBalance, actualBalance);
	}
	@Test(expected = AccountNotFoundException.class)
	public void testGetAccountDetailsForValidData() throws AccountNotFoundException, InvalidAmountException, InvalidPinNumberException{
		services.fundTransfer(100002, 100003, 1000, 1234);
		Account actualAccount = services.getAccountDetails(100002);
		Transaction transactionAcc1 = new Transaction(100002,1000,"Deposit");
		Map<Long,Transaction> transaction1 = new HashMap<Long, Transaction>();
		transaction1.put(100001L, transactionAcc1); 
		Account expectedAccount =new Account(100002, 1233, "Savings", "Active", 2000, transaction1);;
		Assert.assertEquals(expectedAccount, actualAccount);
	}
	@After
	public void tearDownTestData()
	{
		BankingDBUtil.accounts.clear();
		BankingDBUtil.ACCOUNT_NO_COUNTER=100000L;
	}
	@AfterClass
	public static void tearDownTestEnv() {
		services = null;
	}*/
}
