package com.cg.grocerystore.daoservices;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.grocerystore.beans.Customer;
import com.cg.grocerystore.beans.Product;

public class ProductDAOImpl implements ProductDAO{
	private EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("JPA-PU");
	@Override
	public Product save(Product product) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(product);
		entityManager.getTransaction().commit();
		entityManager.close();
		return product;
	}
	@Override
	public boolean update(Product product) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(product);
		entityManager.getTransaction().commit();
		entityManager.close();
		return true;
	}
	@Override
	public Product findOne(long productId) {
		return entityManagerFactory.createEntityManager().find(Product.class, productId);
	}
	@Override
	public List<Product> findAll(long customerId) {
		Query query = entityManagerFactory.createEntityManager().createQuery("from Customer c where customerId = "+customerId, Customer.class);
		return query.getResultList();
	}
	
}
