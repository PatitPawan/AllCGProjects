package com.cg.grocerystore.services;
import java.util.ArrayList;
import java.util.List;
import com.cg.grocerystore.beans.Customer;
import com.cg.grocerystore.beans.Product;
import com.cg.grocerystore.daoservices.CustomerDAO;
import com.cg.grocerystore.daoservices.CustomerDAOImpl;
import com.cg.grocerystore.daoservices.ProductDAO;
import com.cg.grocerystore.daoservices.ProductDAOImpl;
import com.cg.grocerystore.exceptions.CustomerDetailsNotFoundException;
import com.cg.grocerystore.exceptions.GroceryStoreServicesDownException;
import com.cg.grocerystore.exceptions.InvalidQuantityException;
import com.cg.grocerystore.exceptions.ProductDetailsNotFoundException;

public class StoreServicesImpl  implements StoreServices{
	private CustomerDAO customerDao = new CustomerDAOImpl();
	private ProductDAO productDao = new ProductDAOImpl() ;
	@Override
	public Product addProduct(Product product) throws GroceryStoreServicesDownException {
		product = productDao.save(product);
		return product;
	}
	@Override
	public Customer addCustomer(Customer customer) throws GroceryStoreServicesDownException {
		customer = customerDao.save(customer);
		return customer;
	}
	@Override
	public List<Customer> getAllCustomerDetails() throws GroceryStoreServicesDownException {
		return customerDao.findAll();
	}
	@Override
	public List<Product> getCustomerAllProducts(long customerId) throws GroceryStoreServicesDownException, CustomerDetailsNotFoundException {
		return productDao.findAll(customerId);
	}
	@Override
	public Customer getCustomerDetails(long customerId) throws CustomerDetailsNotFoundException, GroceryStoreServicesDownException {
		Customer customer = customerDao.findOne(customerId);
		if(customer==null) {
			throw new CustomerDetailsNotFoundException("Incorrect Customer Id.");
		}
		return customer;
	}
	@Override
	public Product getProductDetails(long productId) throws ProductDetailsNotFoundException, GroceryStoreServicesDownException {
		Product product = productDao.findOne(productId);
		if(product ==null) {
			throw new ProductDetailsNotFoundException("Incorrect Product Code.");
		}
		return product;
	}
	@Override
	public int addToCart(long productId, int quantity) throws GroceryStoreServicesDownException, ProductDetailsNotFoundException, InvalidQuantityException {
		int totalPrice = 0;
		if(quantity<=0) {
			throw new InvalidQuantityException("Incorrect Product Quantity");
		}
		Product product = getProductDetails(productId);
		if(product==null) {
			throw new ProductDetailsNotFoundException("Incorrect Product Code");
		}
		else {
			totalPrice =  (int) (product.getPrice()*quantity);
		}
		return totalPrice;
	}
}
