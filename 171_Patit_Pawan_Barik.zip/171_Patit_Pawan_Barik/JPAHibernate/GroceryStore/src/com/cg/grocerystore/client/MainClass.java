package com.cg.grocerystore.client;

import java.util.List;
import java.util.Scanner;

import com.cg.grocerystore.beans.Customer;
import com.cg.grocerystore.beans.Product;
import com.cg.grocerystore.services.StoreServices;
import com.cg.grocerystore.services.StoreServicesImpl;

public class MainClass {
	public static void main(String [] args) {
		StoreServices services = new StoreServicesImpl(); 
		Scanner sc = new Scanner(System.in);
		int choice =0;
		long customerId = 0;
		long productId = 0;
		boolean flag = true;
		if(flag==true) {
			System.out.println();
			System.out.println("Enter Choice: ");
			choice = sc.nextInt();
			switch(choice)
			{
			case 1://Add Product
				System.out.println("Enter Product Details: ");
				System.out.println("Product Name: ");
				String productName = sc.next();
				System.out.println("Product Price: ");
				int price = sc.nextInt();
				Product product = new Product(productName,price);
				product = services.addProduct(product);
				System.out.println("Product: "+product);
				break;
			case 2://Add Customer
				System.out.println("Enter Customer Details: ");
				System.out.println("Customer Name: ");
				String customerName = sc.next();
				System.out.println("Product Price: ");
				String customerArea = sc.next();
				Customer customer = new Customer(customerName,customerArea);
				customer = services.addCustomer(customer);
				System.out.println("Customer : "+customer);
				break;
			case 3://Get All Customer Details
				System.out.println(services.getAllCustomerDetails());
				break;
			case 4://Get Customer All Products
				System.out.println("Enter Customer Id: ");
				customerId=sc.nextLong();
				System.out.println("Products: "+services.getCustomerAllProducts(customerId));
				break;
			case 5://Add To Cart
				boolean addMore = true;
				price = 0;
				while(addMore==true) {
					System.out.println("Enter Product Id: ");
					productId = sc.nextLong();
					System.out.println("Enter Quantity: ");
					int quantity = sc.nextInt();
					price += services.addToCart(productId, quantity);
					System.out.println("Want to add more products? Y/N");
					String option = sc.next();
					if(option.equalsIgnoreCase("N")) {
						addMore = false;
					}
				}
				System.out.println("Total Cart Value : " + price);
				break;
			case 6: //Exit
				flag=false;
				break;
			default:System.out.println("Wrong Choice.");
				break;
			}
		}	
	}
}
