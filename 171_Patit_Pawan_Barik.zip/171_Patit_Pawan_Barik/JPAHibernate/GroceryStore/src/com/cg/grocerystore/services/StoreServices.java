package com.cg.grocerystore.services;
import java.util.List;
import com.cg.grocerystore.beans.Customer;
import com.cg.grocerystore.beans.Product;
import com.cg.grocerystore.exceptions.CustomerDetailsNotFoundException;
import com.cg.grocerystore.exceptions.GroceryStoreServicesDownException;
import com.cg.grocerystore.exceptions.ProductDetailsNotFoundException;

public interface StoreServices {
	int addToCart(long productId, int quantity) throws GroceryStoreServicesDownException, ProductDetailsNotFoundException;
	Product addProduct(Product product) throws GroceryStoreServicesDownException;
	Customer addCustomer(Customer customer) throws GroceryStoreServicesDownException;
	Customer getCustomerDetails(long customerId) throws CustomerDetailsNotFoundException, GroceryStoreServicesDownException;
	Product getProductDetails(long productId) throws ProductDetailsNotFoundException, GroceryStoreServicesDownException;
	List<Product> getCustomerAllProducts(long CustomerId) throws GroceryStoreServicesDownException, CustomerDetailsNotFoundException;
	List<Customer> getAllCustomerDetails() throws GroceryStoreServicesDownException;
}
