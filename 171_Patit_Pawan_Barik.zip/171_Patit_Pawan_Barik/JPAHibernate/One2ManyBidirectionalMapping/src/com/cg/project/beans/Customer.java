package com.cg.project.beans;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Customer {
	@Id
	@GeneratedValue(strategy= GenerationType.AUTO)
	private int customerNo;
	private String firstName, lastname;
	@OneToMany(mappedBy = "customer")
	private List<Car> cars;
	
	public Customer() {
		super();
	}

	public Customer(int customerNo, String firstName, String lastname, List<Car> cars) {
		super();
		this.customerNo = customerNo;
		this.firstName = firstName;
		this.lastname = lastname;
		this.cars = cars;
	}
	
}
