function sayHello(){
	document.getElementById("msg").innerHtml="<font color = green size=10>Hello World on Browser</font>"
	console.log("Hello World on Console")
}
