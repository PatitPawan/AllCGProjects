//package com.cg.payroll.test;
//
//import static org.junit.Assert.fail;
//import java.util.ArrayList;
//import org.junit.After;
//import org.junit.AfterClass;
//import org.junit.Assert;
//import org.junit.Before;
//import org.junit.BeforeClass;
//import org.junit.Test;
//import com.cg.payroll.beans.Associate;
//import com.cg.payroll.beans.BankDetails;
//import com.cg.payroll.beans.Salary;
//import com.cg.payroll.exceptions.AssociateDetailNotfoundException;
//import com.cg.payroll.services.PayrollServices;
//import com.cg.payroll.services.PayrollServicesImpl;
//
//public class PayrollServicesTest {
//	public  static PayrollServices  services;
//	@BeforeClass
//	public static void setUpTestEnv() {
//		services = new PayrollServicesImpl();
//	}
//	@Test(expected = AssociateDetailNotfoundException.class)
//		public void testGetAssociateDetailsForInvalidAssociateId() throws AssociateDetailNotfoundException{
//			services.getAssociateDetails(103);
//	}
//	@Test
//	public void testGetAssociateDetailsForValidAssociateId() throws AssociateDetailNotfoundException{
//		Associate expectedAssociate = new Associate(1,120000,"PATIT PAWAN","BARIK","IT","ANALYST","CCHPB74A","PP1197BARIK",new Salary(20000, 6000,6000, 5000, 4000, 16, 1000,1000,31000, 28984),new BankDetails(1234, "HDFC", "HDFC123"));
//		Associate actualAssociate = services.getAssociateDetails(1);
//		Assert.assertEquals(expectedAssociate,actualAssociate);
//	}
//	@Test
//	public void testAcceptAssociateDetails(){
//		int expectedAssociateId = 2;
//		int actualAssociateId = services.acceptAssociateDetails("SHYAM","KUMAR","SHYAMKUMAR@","SE","ANALYST","CHCH123",120000,20000,1000,1000,12345, "SBI", "SBI123");
//		Assert.assertEquals(expectedAssociateId,actualAssociateId);
//	}
//	@Test
//	public void testCalculateNetSalaryForValidAssociate(){
//		int expectedNetSalary = 28984;
//		int actualNetSalary = services.calculateNetSalary(1);
//		Assert.assertEquals(expectedNetSalary,actualNetSalary);
//	}
//	@Test(expected=AssociateDetailNotfoundException.class)
//	public void testCalculateNetSalaryForInvalidAssociate()throws AssociateDetailNotfoundException{
//		services.calculateNetSalary(123);
//	}
//	@Test
//	public void testGetAllAssociateDetails(){
//		Associate associate1 = new Associate(1,120000,"PATIT PAWAN","BARIK","IT","ANALYST","CCHPB74A","PP1197BARIK",new Salary(20000, 6000,6000, 5000, 4000, 16, 1000,1000,31000, 28984),new BankDetails(1234, "HDFC", "HDFC123"));
//		Associate associate2 = new Associate(2,80000,"Shyam","kumar","SE","ANALYST","CHCH","shayamkumar@",new Salary(35000, 1200, 1200),new BankDetails(12345, "SBI", "SBI123"));
//		ArrayList<Associate> expectedAssociateList = new ArrayList<Associate>();
//		expectedAssociateList.add(associate1);
//		expectedAssociateList.add(associate2);
//		ArrayList<Associate>actualAssociateList = (ArrayList<Associate>) services.getAllAssociateDetails();
//		Assert.assertEquals(expectedAssociateList, actualAssociateList);
//	}
//	@AfterClass
//	public static void tearDownTestEnv(){
//		services = null;
//	}
//}
